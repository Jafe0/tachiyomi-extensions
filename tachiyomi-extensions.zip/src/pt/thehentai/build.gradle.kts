plugins {
    id("tachiyomi.extension")
}

extension {
    name = "The Hentai"
    pkgName = "pt.thehentai"
    lang = "pt-BR"
}