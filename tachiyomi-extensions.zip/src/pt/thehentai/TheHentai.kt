package eu.kanade.tachiyomi.extension.pt.thehentai

import eu.kanade.tachiyomi.multisrc.madara.Madara

class TheHentai : Madara(
    "The Hentai",
    "https://thehentai.net",
    "pt-BR"
)